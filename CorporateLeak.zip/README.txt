Nexora Company suspects that an internal employee leaked confidential company data. The SOC team recovered several artifacts from the employee workstation, including internal documents, infrastructure backups, and captured network traffic.
Investigate the recovered evidence and determine what was leaked.
Flag Format: Securinets{w1_w2_w3_w4}